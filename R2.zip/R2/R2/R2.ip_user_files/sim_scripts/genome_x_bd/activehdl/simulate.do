transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

asim +access +r +m+genome_x_bd  -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.genome_x_bd xil_defaultlib.glbl

do {genome_x_bd.udo}

run 1000ns

endsim

quit -force
