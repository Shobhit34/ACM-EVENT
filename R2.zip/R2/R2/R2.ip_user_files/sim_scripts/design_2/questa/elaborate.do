vopt -l elaborate.log +acc=npr -suppress 10016  -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.design_2 xil_defaultlib.glbl -o design_2_opt
