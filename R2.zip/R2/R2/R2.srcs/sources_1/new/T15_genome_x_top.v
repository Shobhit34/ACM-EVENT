// ============================================================================
// T15_genome_x_top
// Single-target GENOME-X pipeline: Search → Edit → Verify
// ============================================================================
module T15_genome_x_top (
    input  wire        clk,
    input  wire        rst,            // active-high synchronous
    input  wire        start,
    input  wire [63:0] genome,
    input  wire [15:0] guide,
    input  wire [7:0]  replacement,
    input  wire [1:0]  threshold,

    output reg  [63:0] edited_genome,
    output reg         pipeline_done,
    output reg         pipeline_pass,
    output reg  [4:0]  target_position,
    output reg         target_found,
    output reg  [7:0]  status
);

    // FSM states
    localparam IDLE    = 3'd0;
    localparam SEARCH  = 3'd1;
    localparam EDIT    = 3'd2;
    localparam VERIFY  = 3'd3;
    localparam DONE    = 3'd4;

    reg [2:0] state;

    // Internal control signals
    reg         locator_start;
    wire        locator_done;
    wire        locator_found;
    wire [4:0]  locator_position;
    wire [3:0]  locator_mismatches;

    reg         editor_request;
    wire [63:0] editor_genome_out;
    wire        editor_success;
    wire        editor_done;

    reg         verifier_request;
    wire        verifier_pass;
    wire [5:0]  verifier_mismatches;
    wire        verifier_done;

    // Latched values
    reg [63:0]  original_genome;
    reg [4:0]   found_position;
    reg         found_flag;
    reg         edit_ok;
    reg         verify_ok;

    // ------------------------------------------------------------------
    // Round-1 module instantiations
    // ------------------------------------------------------------------
    T15_target_locator u_locator (
        .clk             (clk),
        .rst             (rst),
        .start           (locator_start),
        .genome          (genome),
        .guide           (guide),
        .threshold       (threshold),
        .target_found    (locator_found),
        .target_position (locator_position),
        .mismatch_count  (locator_mismatches),
        .done            (locator_done)
    );

    T15_genome_editor u_editor (
        .clk             (clk),
        .rst             (rst),
        .edit_request    (editor_request),
        .genome_in       (original_genome),
        .edit_position   (found_position),
        .replacement     (replacement),
        .genome_out      (editor_genome_out),
        .edit_success    (editor_success),
        .done            (editor_done)
    );

    T15_edit_verifier u_verifier (
        .clk              (clk),
        .rst              (rst),
        .verify_request   (verifier_request),
        .genome_original  (original_genome),
        .genome_edited    (editor_genome_out),
        .edit_position    (found_position),
        .replacement      (replacement),
        .verify_pass      (verifier_pass),
        .mismatch_count   (verifier_mismatches),
        .done             (verifier_done)
    );

    // ------------------------------------------------------------------
    // Main FSM
    // ------------------------------------------------------------------
    always @(posedge clk) begin
        if (rst) begin
            state            <= IDLE;
            pipeline_done    <= 1'b0;
            pipeline_pass    <= 1'b0;
            target_position  <= 5'd0;
            target_found     <= 1'b0;
            edited_genome    <= 64'd0;
            status           <= 8'b0;

            locator_start    <= 1'b0;
            editor_request   <= 1'b0;
            verifier_request <= 1'b0;

            original_genome  <= 64'd0;
            found_position   <= 5'd0;
            found_flag       <= 1'b0;
            edit_ok          <= 1'b0;
            verify_ok        <= 1'b0;
        end
        else begin
            // Default: clear one-cycle pulses
            locator_start    <= 1'b0;
            editor_request   <= 1'b0;
            verifier_request <= 1'b0;
            pipeline_done    <= 1'b0;

            case (state)
                IDLE: begin
                    status[1:0] <= 2'b00;   // Idle
                    if (start) begin
                        original_genome <= genome;
                        found_flag      <= 1'b0;
                        edit_ok         <= 1'b0;
                        verify_ok       <= 1'b0;
                        locator_start   <= 1'b1;
                        state           <= SEARCH;
                    end
                end

                SEARCH: begin
                    status[1:0] <= 2'b01;   // Searching
                    if (locator_done) begin
                        found_flag      <= locator_found;
                        found_position  <= locator_position;
                        target_found    <= locator_found;
                        target_position <= locator_position;

                        if (locator_found) begin
                            editor_request <= 1'b1;
                            state          <= EDIT;
                        end else begin
                            edited_genome  <= original_genome;
                            pipeline_pass  <= 1'b0;
                            state          <= DONE;
                        end
                    end
                end

                EDIT: begin
                    status[1:0] <= 2'b10;   // Editing
                    if (editor_done) begin
                        edit_ok       <= editor_success;
                        edited_genome <= editor_genome_out;

                        if (editor_success) begin
                            verifier_request <= 1'b1;
                            state            <= VERIFY;
                        end else begin
                            pipeline_pass <= 1'b0;
                            state         <= DONE;
                        end
                    end
                end

                VERIFY: begin
                    status[1:0] <= 2'b11;   // Verifying
                    if (verifier_done) begin
                        verify_ok     <= verifier_pass;
                        pipeline_pass <= verifier_pass;
                        state         <= DONE;
                    end
                end

                DONE: begin
                    pipeline_done <= 1'b1;

                    // Final status encoding
                    status[1:0] <= 2'b00;          // Idle
                    status[2]   <= found_flag;     // target_found
                    status[3]   <= edit_ok;        // edit_success
                    status[4]   <= verify_ok;      // verify_pass
                    status[5]   <= 1'b0;           // error
                    status[7:6] <= 2'b00;

                    state <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule