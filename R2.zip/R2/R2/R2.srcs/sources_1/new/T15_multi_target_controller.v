// ============================================================================
// T15_multi_target_controller
// Finds and edits ALL matching targets in the genome (cumulative)
// ============================================================================
module T15_multi_target_controller (
    input  wire        clk,
    input  wire        rst,
    input  wire        start,
    input  wire [63:0] genome,
    input  wire [15:0] guide,
    input  wire [7:0]  replacement,
    input  wire [1:0]  threshold,

    output reg  [63:0] final_genome,
    output reg  [4:0]  targets_found,
    output reg  [4:0]  edits_applied,
    output reg  [4:0]  edits_verified,
    output reg         all_done,
    output reg         all_pass
);

    // ------------------------------------------------------------------
    // FSM states
    // ------------------------------------------------------------------
    localparam IDLE     = 3'd0;
    localparam SEARCH   = 3'd1;
    localparam EDIT     = 3'd2;
    localparam VERIFY   = 3'd3;
    localparam NEXT     = 3'd4;
    localparam DONE     = 3'd5;

    reg [2:0] state;

    // ------------------------------------------------------------------
    // Internal signals
    // ------------------------------------------------------------------
    reg  [63:0] current_genome;
    reg  [4:0]  search_pos;          // current search starting position
    reg  [4:0]  found_pos;
    reg         found_flag;

    // Locator control
    reg         loc_start;
    wire        loc_done;
    wire        loc_found;
    wire [4:0]  loc_position;
    wire [3:0]  loc_mismatches;

    // Editor control
    reg         edit_req;
    wire [63:0] edit_out;
    wire        edit_success;
    wire        edit_done;

    // Verifier control
    reg         ver_req;
    wire        ver_pass;
    wire [5:0]  ver_mismatches;
    wire        ver_done;

    // Counters
    reg [4:0]   cnt_targets;
    reg [4:0]   cnt_applied;
    reg [4:0]   cnt_verified;

    // ------------------------------------------------------------------
    // Instantiate Round-1 modules
    // ------------------------------------------------------------------
    T15_target_locator u_locator (
        .clk             (clk),
        .rst             (rst),
        .start           (loc_start),
        .genome          (current_genome),
        .guide           (guide),
        .threshold       (threshold),
        .target_found    (loc_found),
        .target_position (loc_position),
        .mismatch_count  (loc_mismatches),
        .done            (loc_done)
    );

    T15_genome_editor u_editor (
        .clk             (clk),
        .rst             (rst),
        .edit_request    (edit_req),
        .genome_in       (current_genome),
        .edit_position   (found_pos),
        .replacement     (replacement),
        .genome_out      (edit_out),
        .edit_success    (edit_success),
        .done            (edit_done)
    );

    T15_edit_verifier u_verifier (
        .clk              (clk),
        .rst              (rst),
        .verify_request   (ver_req),
        .genome_original  (current_genome),
        .genome_edited    (edit_out),
        .edit_position    (found_pos),
        .replacement      (replacement),
        .verify_pass      (ver_pass),
        .mismatch_count   (ver_mismatches),
        .done             (ver_done)
    );

    // ------------------------------------------------------------------
    // Main FSM
    // ------------------------------------------------------------------
    always @(posedge clk) begin
        if (rst) begin
            state           <= IDLE;
            final_genome    <= 64'd0;
            targets_found   <= 5'd0;
            edits_applied   <= 5'd0;
            edits_verified  <= 5'd0;
            all_done        <= 1'b0;
            all_pass        <= 1'b0;

            current_genome  <= 64'd0;
            search_pos      <= 5'd0;
            found_pos       <= 5'd0;
            found_flag      <= 1'b0;

            loc_start       <= 1'b0;
            edit_req        <= 1'b0;
            ver_req         <= 1'b0;

            cnt_targets     <= 5'd0;
            cnt_applied     <= 5'd0;
            cnt_verified    <= 5'd0;
        end
        else begin
            // default pulses
            loc_start <= 1'b0;
            edit_req  <= 1'b0;
            ver_req   <= 1'b0;
            all_done  <= 1'b0;

            case (state)
                // ------------------------------------------------------
                IDLE: begin
                    if (start) begin
                        current_genome <= genome;
                        search_pos     <= 5'd0;
                        cnt_targets    <= 5'd0;
                        cnt_applied    <= 5'd0;
                        cnt_verified   <= 5'd0;
                        all_pass       <= 1'b1;   // assume pass until fail
                        loc_start      <= 1'b1;
                        state          <= SEARCH;
                    end
                end

                // ------------------------------------------------------
                SEARCH: begin
                    if (loc_done) begin
                        if (loc_found && (loc_position >= search_pos)) begin
                            // Valid new target found
                            found_flag   <= 1'b1;
                            found_pos    <= loc_position;
                            cnt_targets  <= cnt_targets + 1'b1;
                            edit_req     <= 1'b1;
                            state        <= EDIT;
                        end
                        else begin
                            // No more targets
                            final_genome   <= current_genome;
                            targets_found  <= cnt_targets;
                            edits_applied  <= cnt_applied;
                            edits_verified <= cnt_verified;
                            all_done       <= 1'b1;
                            state          <= DONE;
                        end
                    end
                end

                // ------------------------------------------------------
                EDIT: begin
                    if (edit_done) begin
                        if (edit_success) begin
                            cnt_applied <= cnt_applied + 1'b1;
                            ver_req     <= 1'b1;
                            state       <= VERIFY;
                        end
                        else begin
                            // Edit failed
                            all_pass       <= 1'b0;
                            final_genome   <= current_genome;
                            targets_found  <= cnt_targets;
                            edits_applied  <= cnt_applied;
                            edits_verified <= cnt_verified;
                            all_done       <= 1'b1;
                            state          <= DONE;
                        end
                    end
                end

                // ------------------------------------------------------
                VERIFY: begin
                    if (ver_done) begin
                        if (ver_pass) begin
                            // Accept the edit
                            current_genome <= edit_out;
                            cnt_verified   <= cnt_verified + 1'b1;

                            // Continue search from next position
                            search_pos     <= found_pos + 1'b1;
                            loc_start      <= 1'b1;
                            state          <= SEARCH;
                        end
                        else begin
                            // Verification failed → stop
                            all_pass       <= 1'b0;
                            final_genome   <= current_genome;
                            targets_found  <= cnt_targets;
                            edits_applied  <= cnt_applied;
                            edits_verified <= cnt_verified;
                            all_done       <= 1'b1;
                            state          <= DONE;
                        end
                    end
                end

                // ------------------------------------------------------
                DONE: begin
                    // Stay here until next start
                    // all_done already pulsed
                    if (start) begin
                        // Allow restart
                        current_genome <= genome;
                        search_pos     <= 5'd0;
                        cnt_targets    <= 5'd0;
                        cnt_applied    <= 5'd0;
                        cnt_verified   <= 5'd0;
                        all_pass       <= 1'b1;
                        loc_start      <= 1'b1;
                        state          <= SEARCH;
                    end
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule