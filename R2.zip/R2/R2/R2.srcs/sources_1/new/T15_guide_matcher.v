module T15_guide_matcher (
    input  [15:0] guide,
    input  [15:0] window,
    input  [1:0] threshold,
    output reg [3:0] mismatch_count,
    output reg match
);

integer i;

always @(*) begin
    mismatch_count = 0;
    match = 0;

    for (i = 0; i < 8; i = i + 1) begin
        if (guide[15 - 2*i -: 2] != window[15 - 2*i -: 2])
            mismatch_count = mismatch_count + 1'b1;
    end

    if (mismatch_count <= threshold)
        match = 1'b1;
end

endmodule