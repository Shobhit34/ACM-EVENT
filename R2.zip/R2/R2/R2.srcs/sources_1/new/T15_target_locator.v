module T15_target_locator (
    input clk,
    input rst,
    input start,
    input [63:0] genome,
    input [15:0] guide,
    input [1:0] threshold,
    output reg target_found,
    output reg [4:0] target_position,
    output reg [3:0] mismatch_count,
    output reg done
);

reg [4:0] position;
reg busy;
wire [15:0] candidate_window;
wire [3:0] candidate_mismatches;
wire candidate_match;

assign candidate_window = genome[63 - 2*position -: 16];

T15_guide_matcher matcher (
    .guide(guide),
    .window(candidate_window),
    .threshold(threshold),
    .mismatch_count(candidate_mismatches),
    .match(candidate_match)
);

always @(posedge clk) begin
    if (rst) begin
        position <= 0;
        target_found <= 0;
        target_position <= 0;
        mismatch_count <= 0;
        done <= 0;
        busy <= 0;
    end else begin
        done <= 0;

        if (start && !busy) begin
            position <= 0;
            target_found <= 0;
            target_position <= 0;
            mismatch_count <= 0;
            busy <= 1;
        end else if (busy) begin
            if (candidate_match) begin
                target_found <= 1;
                target_position <= position;
                mismatch_count <= candidate_mismatches;
                done <= 1;
                busy <= 0;
            end else if (position == 24) begin
                target_found <= 0;
                done <= 1;
                busy <= 0;
            end else begin
                position <= position + 1'b1;
            end
        end
    end
end

endmodule