module T15_genome_editor (
    input clk,
    input rst,
    input edit_request,
    input [63:0] genome_in,
    input [4:0] edit_position,
    input [7:0] replacement,
    output reg [63:0] genome_out,
    output reg edit_success,
    output reg done
);

reg [63:0] edited_temp;
reg busy;
integer i;

always @(*) begin
    edited_temp = genome_in;

    if (edit_position <= 28) begin
        for (i = 0; i < 4; i = i + 1) begin
            edited_temp[63 - 2*(edit_position+i) -: 2] =
                replacement[7 - 2*i -: 2];
        end
    end
end

always @(posedge clk) begin
    if (rst) begin
        genome_out <= 0;
        edit_success <= 0;
        done <= 0;
        busy <= 0;
    end else begin
        done <= 0;

        if (!edit_request)
            busy <= 0;

        if (edit_request && !busy) begin
            done <= 1;
            busy <= 1;

            if (edit_position <= 28) begin
                genome_out <= edited_temp;
                edit_success <= 1;
            end else begin
                genome_out <= genome_in;
                edit_success <= 0;
            end
        end
    end
end

endmodule