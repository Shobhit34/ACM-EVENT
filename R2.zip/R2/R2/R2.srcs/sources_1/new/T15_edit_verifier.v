module T15_edit_verifier (
    input clk,
    input rst,
    input verify_request,
    input [63:0] genome_original,
    input [63:0] genome_edited,
    input [4:0] edit_position,
    input [7:0] replacement,
    output reg verify_pass,
    output reg [5:0] mismatch_count,
    output reg done
);

reg [63:0] expected_genome;
reg [5:0] difference_count;
reg busy;
integer i;

always @(*) begin
    expected_genome = genome_original;
    difference_count = 0;

    if (edit_position <= 28) begin
        for (i = 0; i < 4; i = i + 1) begin
            expected_genome[63 - 2*(edit_position+i) -: 2] =
                replacement[7 - 2*i -: 2];
        end
    end

    for (i = 0; i < 32; i = i + 1) begin
        if (expected_genome[63 - 2*i -: 2] !=
            genome_edited[63 - 2*i -: 2])
            difference_count = difference_count + 1'b1;
    end
end

always @(posedge clk) begin
    if (rst) begin
        verify_pass <= 0;
        mismatch_count <= 0;
        done <= 0;
        busy <= 0;
    end else begin
        done <= 0;

        if (!verify_request)
            busy <= 0;

        if (verify_request && !busy) begin
            mismatch_count <= difference_count;
            verify_pass <= (edit_position <= 28) &&
                           (difference_count == 0);
            done <= 1;
            busy <= 1;
        end
    end
end

endmodule