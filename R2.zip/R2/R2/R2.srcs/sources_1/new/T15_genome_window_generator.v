module T15_genome_window_generator (
    input clk,
    input rst,
    input [15:0] fragment,
    input fragment_valid,
    output reg [15:0] window,
    output reg window_valid
);

reg [15:0] previous_fragment;
reg [31:0] combined;
reg have_previous;
reg busy;
reg [3:0] offset;

always @(posedge clk) begin
    if (rst) begin
        previous_fragment <= 0;
        combined <= 0;
        have_previous <= 0;
        busy <= 0;
        offset <= 0;
        window <= 0;
        window_valid <= 0;
    end else begin
        window_valid <= 0;

        if (busy) begin
            window <= combined[31 - 2*offset -: 16];
            window_valid <= 1;

            if (offset == 8) begin
                previous_fragment <= combined[15:0];
                busy <= 0;
                offset <= 0;
            end else begin
                offset <= offset + 1'b1;
            end
        end else if (fragment_valid) begin
            if (!have_previous) begin
                window <= fragment;
                window_valid <= 1;
                previous_fragment <= fragment;
                have_previous <= 1;
            end else begin
                combined <= {previous_fragment, fragment};
                offset <= 1;
                busy <= 1;
            end
        end
    end
end

endmodule