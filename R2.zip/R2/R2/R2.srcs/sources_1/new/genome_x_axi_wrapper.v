// ============================================================================
// GENOME-X AXI-Lite Peripheral Wrapper  (PROVIDED - DO NOT MODIFY)
// ============================================================================
module genome_x_axi_wrapper #(
    parameter C_S_AXI_DATA_WIDTH = 32,
    parameter C_S_AXI_ADDR_WIDTH = 6
)(
    // AXI4-Lite Slave Interface
    input  wire                                S_AXI_ACLK,
    input  wire                                S_AXI_ARESETN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0]       S_AXI_AWADDR,
    input  wire [2:0]                          S_AXI_AWPROT,
    input  wire                                S_AXI_AWVALID,
    output wire                                S_AXI_AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0]       S_AXI_WDATA,
    input  wire [(C_S_AXI_DATA_WIDTH/8)-1:0]   S_AXI_WSTRB,
    input  wire                                S_AXI_WVALID,
    output wire                                S_AXI_WREADY,
    output wire [1:0]                          S_AXI_BRESP,
    output wire                                S_AXI_BVALID,
    input  wire                                S_AXI_BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0]       S_AXI_ARADDR,
    input  wire [2:0]                          S_AXI_ARPROT,
    input  wire                                S_AXI_ARVALID,
    output wire                                S_AXI_ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0]       S_AXI_RDATA,
    output wire [1:0]                          S_AXI_RRESP,
    output wire                                S_AXI_RVALID,
    input  wire                                S_AXI_RREADY,

    // Pipeline Interface
    output wire [63:0] pipe_genome,
    output wire [15:0] pipe_guide,
    output wire [7:0]  pipe_replacement,
    output wire [1:0]  pipe_threshold,
    output wire [7:0]  pipe_command,
    output reg         single_start,
    output reg         multi_start,

    input  wire [63:0] single_edited_genome,
    input  wire        single_done,
    input  wire        single_pass,
    input  wire [4:0]  single_target_position,
    input  wire        single_target_found,
    input  wire [7:0]  single_status,

    input  wire [63:0] multi_final_genome,
    input  wire [4:0]  multi_targets_found,
    input  wire [4:0]  multi_edits_applied,
    input  wire [4:0]  multi_edits_verified,
    input  wire        multi_done,
    input  wire        multi_pass,

    output wire        pipe_reset,
    output wire        led_busy,
    output wire        led_pass,
    output wire        led_fail
);

    // Internal AXI signals
    reg [C_S_AXI_ADDR_WIDTH-1:0] axi_awaddr;
    reg        axi_awready;
    reg        axi_wready;
    reg [1:0]  axi_bresp;
    reg        axi_bvalid;
    reg [C_S_AXI_ADDR_WIDTH-1:0] axi_araddr;
    reg        axi_arready;
    reg [C_S_AXI_DATA_WIDTH-1:0] axi_rdata;
    reg [1:0]  axi_rresp;
    reg        axi_rvalid;

    // Register file
    reg [31:0] reg_genome_lo;
    reg [31:0] reg_genome_hi;
    reg [31:0] reg_guide;
    reg [31:0] reg_replacement;
    reg [31:0] reg_threshold;
    reg [31:0] reg_command;

    // Pipeline mapping
    assign pipe_genome      = {reg_genome_hi, reg_genome_lo};
    assign pipe_guide       = reg_guide[15:0];
    assign pipe_replacement = reg_replacement[7:0];
    assign pipe_threshold   = reg_threshold[1:0];
    assign pipe_command     = reg_command[7:0];
    assign pipe_reset       = ~S_AXI_ARESETN;

    // Latency counter
    reg [31:0] latency_counter;
    reg        latency_running;
    reg [31:0] latency_result;

    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN) begin
            latency_counter <= 0;
            latency_running <= 0;
            latency_result  <= 0;
        end else begin
            if (single_start || multi_start) begin
                latency_counter <= 0;
                latency_running <= 1;
            end else if (latency_running) begin
                latency_counter <= latency_counter + 1;
                if (single_done || multi_done) begin
                    latency_running <= 0;
                    latency_result  <= latency_counter + 1;
                end
            end
        end
    end

    // Heartbeat
    reg [31:0] heartbeat;
    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN)
            heartbeat <= 0;
        else
            heartbeat <= heartbeat + 1;
    end

    // Result capture
    reg [63:0] cap_single_genome;
    reg [7:0]  cap_single_status;
    reg [4:0]  cap_single_target_pos;
    reg        cap_single_target_found;
    reg        cap_single_pass;
    reg        cap_single_done;

    reg [63:0] cap_multi_genome;
    reg [4:0]  cap_multi_targets_found;
    reg [4:0]  cap_multi_edits_applied;
    reg [4:0]  cap_multi_edits_verified;
    reg        cap_multi_pass;
    reg        cap_multi_done;

    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN) begin
            cap_single_genome       <= 0;
            cap_single_status       <= 0;
            cap_single_target_pos   <= 0;
            cap_single_target_found <= 0;
            cap_single_pass         <= 0;
            cap_single_done         <= 0;
            cap_multi_genome        <= 0;
            cap_multi_targets_found <= 0;
            cap_multi_edits_applied <= 0;
            cap_multi_edits_verified<= 0;
            cap_multi_pass          <= 0;
            cap_multi_done          <= 0;
        end else begin
            if (single_done) begin
                cap_single_genome       <= single_edited_genome;
                cap_single_status       <= single_status;
                cap_single_target_pos   <= single_target_position;
                cap_single_target_found <= single_target_found;
                cap_single_pass         <= single_pass;
                cap_single_done         <= 1;
            end
            if (multi_done) begin
                cap_multi_genome        <= multi_final_genome;
                cap_multi_targets_found <= multi_targets_found;
                cap_multi_edits_applied <= multi_edits_applied;
                cap_multi_edits_verified<= multi_edits_verified;
                cap_multi_pass          <= multi_pass;
                cap_multi_done          <= 1;
            end
            if (single_start) cap_single_done <= 0;
            if (multi_start)  cap_multi_done  <= 0;
        end
    end

    // LEDs
    assign led_busy = latency_running;
    assign led_pass = cap_single_pass | cap_multi_pass;
    assign led_fail = (cap_single_done & ~cap_single_pass) | (cap_multi_done & ~cap_multi_pass);

    // AXI Write logic
    wire aw_handshake = S_AXI_AWVALID & axi_awready;
    wire w_handshake  = S_AXI_WVALID  & axi_wready;

    assign S_AXI_AWREADY = axi_awready;
    assign S_AXI_WREADY  = axi_wready;
    assign S_AXI_BRESP   = axi_bresp;
    assign S_AXI_BVALID  = axi_bvalid;

    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN) begin
            axi_awready <= 0;
            axi_awaddr  <= 0;
        end else begin
            if (~axi_awready && S_AXI_AWVALID && S_AXI_WVALID) begin
                axi_awready <= 1;
                axi_awaddr  <= S_AXI_AWADDR;
            end else begin
                axi_awready <= 0;
            end
        end
    end

    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN)
            axi_wready <= 0;
        else if (~axi_wready && S_AXI_WVALID && S_AXI_AWVALID)
            axi_wready <= 1;
        else
            axi_wready <= 0;
    end

    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN) begin
            axi_bvalid <= 0;
            axi_bresp  <= 0;
        end else begin
            if (aw_handshake && w_handshake && ~axi_bvalid) begin
                axi_bvalid <= 1;
                axi_bresp  <= 2'b00;
            end else if (S_AXI_BREADY && axi_bvalid) begin
                axi_bvalid <= 0;
            end
        end
    end

    // Register writes + start pulses
    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN) begin
            reg_genome_lo   <= 0;
            reg_genome_hi   <= 0;
            reg_guide       <= 0;
            reg_replacement <= 0;
            reg_threshold   <= 0;
            reg_command     <= 0;
            single_start    <= 0;
            multi_start     <= 0;
        end else begin
            single_start <= 0;
            multi_start  <= 0;

            if (aw_handshake && w_handshake) begin
                case (axi_awaddr[5:2])
                    4'h0: reg_genome_lo   <= S_AXI_WDATA;
                    4'h1: reg_genome_hi   <= S_AXI_WDATA;
                    4'h2: reg_guide       <= S_AXI_WDATA;
                    4'h3: reg_replacement <= S_AXI_WDATA;
                    4'h4: reg_threshold   <= S_AXI_WDATA;
                    4'h5: begin
                        reg_command <= S_AXI_WDATA;
                        if (S_AXI_WDATA[7:0] == 8'h01 || S_AXI_WDATA[7:0] == 8'h03)
                            single_start <= 1;
                        if (S_AXI_WDATA[7:0] == 8'h02)
                            multi_start <= 1;
                    end
                endcase
            end
        end
    end

    // AXI Read logic
    assign S_AXI_ARREADY = axi_arready;
    assign S_AXI_RDATA   = axi_rdata;
    assign S_AXI_RRESP   = axi_rresp;
    assign S_AXI_RVALID  = axi_rvalid;

    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN) begin
            axi_arready <= 0;
            axi_araddr  <= 0;
        end else begin
            if (~axi_arready && S_AXI_ARVALID) begin
                axi_arready <= 1;
                axi_araddr  <= S_AXI_ARADDR;
            end else begin
                axi_arready <= 0;
            end
        end
    end

    always @(posedge S_AXI_ACLK) begin
        if (~S_AXI_ARESETN) begin
            axi_rvalid <= 0;
            axi_rresp  <= 0;
            axi_rdata  <= 0;
        end else begin
            if (axi_arready && S_AXI_ARVALID && ~axi_rvalid) begin
                axi_rvalid <= 1;
                axi_rresp  <= 2'b00;

                case (axi_araddr[5:2])
                    4'h6: axi_rdata <= {16'b0, cap_single_status, 
                                       4'b0, cap_multi_pass, cap_single_pass, 
                                       cap_multi_done, cap_single_done};
                    4'h7: axi_rdata <= cap_single_genome[31:0];
                    4'h8: axi_rdata <= cap_single_genome[63:32];
                    4'h9: axi_rdata <= {26'b0, cap_single_target_found, cap_single_target_pos};
                    4'hA: axi_rdata <= cap_multi_genome[31:0];
                    4'hB: axi_rdata <= cap_multi_genome[63:32];
                    4'hC: axi_rdata <= {17'b0, cap_multi_edits_verified, 
                                       cap_multi_edits_applied, cap_multi_targets_found};
                    4'hD: axi_rdata <= {30'b0, cap_multi_pass, cap_multi_done};
                    4'hE: axi_rdata <= latency_result;
                    4'hF: axi_rdata <= heartbeat;
                    default: axi_rdata <= 0;
                endcase
            end else if (axi_rvalid && S_AXI_RREADY) begin
                axi_rvalid <= 0;
            end
        end
    end

endmodule