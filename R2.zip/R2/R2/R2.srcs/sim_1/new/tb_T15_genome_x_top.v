`timescale 1ns / 1ps

module tb_T15_genome_x_top;

    // ---------------------------------------------------------------
    // Clock & Reset
    // ---------------------------------------------------------------
    reg clk;
    reg rst;

    initial begin
        clk = 0;
        forever #5 clk = ~clk;   // 100 MHz
    end

    // ---------------------------------------------------------------
    // DUT signals
    // ---------------------------------------------------------------
    reg         start;
    reg  [63:0] genome;
    reg  [15:0] guide;
    reg  [7:0]  replacement;
    reg  [1:0]  threshold;

    wire [63:0] edited_genome;
    wire        pipeline_done;
    wire        pipeline_pass;
    wire [4:0]  target_position;
    wire        target_found;
    wire [7:0]  status;

    // ---------------------------------------------------------------
    // Instantiate DUT
    // ---------------------------------------------------------------
    T15_genome_x_top dut (
        .clk             (clk),
        .rst             (rst),
        .start           (start),
        .genome          (genome),
        .guide           (guide),
        .replacement     (replacement),
        .threshold       (threshold),
        .edited_genome   (edited_genome),
        .pipeline_done   (pipeline_done),
        .pipeline_pass   (pipeline_pass),
        .target_position (target_position),
        .target_found    (target_found),
        .status          (status)
    );

    // ---------------------------------------------------------------
    // Helper task: run one test
    // ---------------------------------------------------------------
    task run_test;
        input [63:0] t_genome;
        input [15:0] t_guide;
        input [7:0]  t_replacement;
        input [1:0]  t_threshold;
        input [8*32-1:0] test_name;   // just for display
        begin
            $display("\n==============================================");
            $display("TEST: %0s", test_name);
            $display("==============================================");

            // Apply inputs
            genome      = t_genome;
            guide       = t_guide;
            replacement = t_replacement;
            threshold   = t_threshold;

            // Pulse start
            @(posedge clk);
            start = 1;
            @(posedge clk);
            start = 0;

            // Wait for pipeline_done
            wait(pipeline_done == 1);
            @(posedge clk);

            // Print results
            $display("target_found     = %b", target_found);
            $display("target_position  = %0d", target_position);
            $display("pipeline_pass    = %b", pipeline_pass);
            $display("status           = %b", status);
            $display("edited_genome    = %h", edited_genome);

            if (pipeline_pass)
                $display(">>> RESULT: PASS");
            else
                $display(">>> RESULT: FAIL / NO TARGET");
        end
    endtask

    // ---------------------------------------------------------------
    // Main test sequence
    // ---------------------------------------------------------------
    initial begin
        // Initialize
        rst         = 1;
        start       = 0;
        genome      = 0;
        guide       = 0;
        replacement = 0;
        threshold   = 0;

        // Reset
        repeat(5) @(posedge clk);
        rst = 0;
        repeat(2) @(posedge clk);

        // ============================================================
        // TEST 1: Exact match (threshold = 0)
        // Genome has the guide sequence starting at position 4
        // ============================================================
        // Guide = 16'hA5A5  (example)
        // We construct a genome that contains this guide
        run_test(
            64'h0000_A5A5_0000_0000,   // genome (guide at position 8? adjust as needed)
            16'hA5A5,                   // guide
            8'h3C,                      // replacement
            2'd0,                       // threshold = 0 (exact)
            "Exact Match (threshold=0)"
        );

        // ============================================================
        // TEST 2: Fuzzy match (threshold = 1)
        // ============================================================
        run_test(
            64'h0000_A5A7_0000_0000,    // one mismatch
            16'hA5A5,
            8'hF0,
            2'd1,                       // allow 1 mismatch
            "Fuzzy Match (threshold=1)"
        );

        // ============================================================
        // TEST 3: No target found
        // ============================================================
        run_test(
            64'hFFFF_FFFF_FFFF_FFFF,
            16'h0000,
            8'hAA,
            2'd0,
            "No Target Found"
        );

        // ============================================================
        // TEST 4: Boundary position (position 0)
        // ============================================================
        run_test(
            64'hA5A5_0000_0000_0000,    // guide at the very beginning
            16'hA5A5,
            8'h55,
            2'd0,
            "Boundary Position 0"
        );

        // ============================================================
        // Finish
        // ============================================================
        #100;
        $display("\nAll tests completed.");
        $finish;
    end

endmodule