//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Sun Oct 25 16:33:58 2026
//Host        : SHOBHIT running 64-bit major release  (build 9200)
//Command     : generate_target genome_x_bd_wrapper.bd
//Design      : genome_x_bd_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module genome_x_bd_wrapper
   ();


  genome_x_bd genome_x_bd_i
       ();
endmodule
